import random
print('Welcome to the number guessing game!')
print('The computer will choose a number and you are going to guess it..')
print('The number is between 1 and 10 with both included..')
print('You can try until you get it right..')

random_num=random.randint(1,10)
user_num=None
guesses=0

while user_num != random_num:
    try:
        user_num=int(input('Enter your number: '))
        guesses+=1
        if user_num < random_num:
            print('Too low!')
        elif user_num > random_num:
            print('Too high!')
    except ValueError:
        print('Please enter a valid number!')

print(f'Correct! The answer is {random_num}. You got it in {guesses} guesses!')