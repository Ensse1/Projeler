def get_int_input(prompt,valid_options=None):
    while True:
        try:
            value=int(input(prompt))
            if valid_options and value not in valid_options:
                print(f'Please enter one of {valid_options}')
                continue
            return value
        except ValueError:
            print('ERROR: Enter a valid number!')

def caesar(char,shift):
    if char.isupper():
        char=(ord(char)-ord('A')+shift)%26
        return chr(char+ord('A'))
    elif char.islower():
        char=(ord(char)-ord('a')+shift)%26
        return chr(char+ord('a'))
    else:
        return char

print('WELCOME TO THE CAESAR CIPHER PROGRAM!')
shift = get_int_input('Enter your shift number: ')
method = get_int_input('1)Encrypt\n2)Decrypt\nAnswer: ',valid_options=[1,2])
if method == 2:
    shift=-shift
word=input('Enter the word: ')
result=''
for i in word:
    result+=caesar(i,shift)
print(result)