import string
import secrets

print("Welcome to password generator!")
while True:
    try:
        length=int(input("Enter the length of the password: "))
        if length<8:
            print("ERROR:The password length must be higher or equal to 8!")
        else:
            break       
    except ValueError:
        print("ERROR:Enter a valid number!")
result=''
pool=string.ascii_letters+string.digits+string.punctuation
for i in range(length):
    result+=secrets.choice(pool)
print(result)